Suman Portfolio

Before publishing:
1. Open index.html.
2. Replace YOUR_EMAIL@example.com with your professional email.
3. Replace the concept-project descriptions with real work as you create it.
4. Publish the folder using GitHub Pages or Netlify.
